#!/bin/bash
# Simple Calculator Script

# Prompt the user for the first number
echo "Enter the first number:"
read num1

# Prompt the user for the second number
echo "Enter the second number:"
read num2

# Prompt the user for the operation
echo "Enter the operation (+, -, *, /):"
read op

# Perform the calculation
case $op in
    +)
        result=$(echo "$num1 + $num2" | bc)
        ;;
    -)
        result=$(echo "$num1 - $num2" | bc)
        ;;
    \*)
        result=$(echo "$num1 * $num2" | bc)
        ;;
    /)
        # Check if the second number is not zero
        if [ "$num2" -eq 0 ]; then
            echo "Division by zero is not allowed."
            exit 1
        fi
        result=$(echo "scale=2; $num1 / $num2" | bc)
        ;;
    *)
        echo "Invalid operation."
        exit 1
        ;;
esac

# Display the result
echo "The result of $num1 $op $num2 is: $result"
