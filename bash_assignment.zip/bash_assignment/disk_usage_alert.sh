#!/bin/bash

# Script to check disk usage and send an alert if it exceeds 80%

# Set the threshold percentage for disk usage
threshold=80

# Get the current disk usage percentage of the root filesystem (/)
usage=$(df / | grep / | awk '{ print $5 }' | sed 's/%//g')

# Check if the usage is above the threshold
if [ $usage -gt $threshold ]; then
    # Send an email alert
    echo "Disk usage is at $usage%, which is above the threshold of $threshold%." | mail -s "Disk Usage Alert" abhay06072002@gmail.com
    echo "Alert sent. Disk usage is at $usage%."
else
    echo "Disk usage is at $usage%. No alert necessary."
fi
