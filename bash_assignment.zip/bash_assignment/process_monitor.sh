#!/bin/bash

# Name of the process to monitor
process_name="apache2"

# Log file to record actions
log_file="$HOME/process_monitor.log"

# Check if the process is running
if pgrep "$process_name" > /dev/null
then
    echo "$(date): $process_name is running." >> "$log_file"
else
    echo "$(date): $process_name is not running. Attempting to start it." >> "$log_file"
    sudo service "$process_name" start
    if [ $? -eq 0 ]; then
        echo "$(date): $process_name started successfully." >> "$log_file"
    else
        echo "$(date): Failed to start $process_name." >> "$log_file"
    fi
fi

