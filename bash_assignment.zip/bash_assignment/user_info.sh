#!/bin/bash

# Script to display user information

# Display the username
echo "Username: $USER"

# Display the user ID (UID)
echo "User ID (UID): $(id -u)"

# Display the group ID (GID)
echo "Group ID (GID): $(id -g)"

# Display the home directory
echo "Home Directory: $HOME"

# Display the shell being used
echo "Shell: $SHELL"
