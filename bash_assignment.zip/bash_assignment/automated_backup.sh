#!/bin/bash

# Directory to back up
src_dir="$HOME/documents"

# Backup destination directory
backup_dir="$HOME/backup"

# Create the backup directory if it doesn't exist
mkdir -p "$backup_dir"

# Create a timestamp for the backup
timestamp=$(date +"%Y%m%d_%H%M%S")

# Name of the backup file
backup_file="documents_backup_$timestamp.tar.gz"

# Create the backup
tar -czf "$backup_dir/$backup_file" -C "$src_dir" .

echo "Backup of $src_dir completed and saved as $backup_dir/$backup_file"
