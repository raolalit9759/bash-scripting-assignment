#!/bin/bash
# Script to generate a system information report

# Output file for the report
OUTPUT="system_report.txt"

# Collect system information
echo "System Information Report" > $OUTPUT
echo "=========================" >> $OUTPUT
echo "" >> $OUTPUT

# System Uptime
echo "System Uptime:" >> $OUTPUT
uptime >> $OUTPUT
echo "" >> $OUTPUT

# Memory Usage
echo "Memory Usage:" >> $OUTPUT
free -h >> $OUTPUT
echo "" >> $OUTPUT

# CPU Load
echo "CPU Load:" >> $OUTPUT
top -bn1 | grep "load average:" >> $OUTPUT
echo "" >> $OUTPUT

# Disk Usage
echo "Disk Usage:" >> $OUTPUT
df -h >> $OUTPUT
echo "" >> $OUTPUT

# Running Processes
echo "Running Processes:" >> $OUTPUT
ps -e >> $OUTPUT

# Indicate completion
echo "System information report generated in $OUTPUT"
