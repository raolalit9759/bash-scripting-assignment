#!/bin/bash

# Script to create a directory structure

# Base directory
base_dir="/home/abhay"

# Create the directory structure
mkdir -p $base_dir/projects/project{1..3}
mkdir -p $base_dir/documents
mkdir -p $base_dir/downloads

echo "Directory structure created under $base_dir"
