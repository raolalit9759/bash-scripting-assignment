#!/bin/bash

# Script to backup .txt files from a given directory

# Check if a directory is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

# Directory to backup
src_dir="$1"

# Create a backup directory with a timestamp
timestamp=$(date +"%Y%m%d_%H%M%S")
backup_dir="$src_dir/backup_$timestamp"

# Create the backup directory
mkdir -p "$backup_dir"

# Copy all .txt files to the backup directory
cp "$src_dir"/*.txt "$backup_dir"

echo "Backup completed. Files copied to $backup_dir"
