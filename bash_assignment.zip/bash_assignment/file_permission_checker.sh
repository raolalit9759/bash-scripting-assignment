#!/bin/bash

# Script to check read, write, and execute permissions of a file

# Check if a file is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <file>"
  exit 1
fi

# Check if the file exists
if [ ! -e "$1" ]; then
  echo "File $1 does not exist."
  exit 1
fi

# Check read permission
if [ -r "$1" ]; then
  echo "The file $1 has read permission."
else
  echo "The file $1 does NOT have read permission."
fi

# Check write permission
if [ -w "$1" ]; then
  echo "The file $1 has write permission."
else
  echo "The file $1 does NOT have write permission."
fi

# Check execute permission
if [ -x "$1" ]; then
  echo "The file $1 has execute permission."
else
  echo "The file $1 does NOT have execute permission."
fi
